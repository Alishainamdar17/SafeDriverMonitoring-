// import 'package:flutter/material.dart';
// import 'package:sensors_plus/sensors_plus.dart';
// import 'package:geolocator/geolocator.dart';
// import 'package:permission_handler/permission_handler.dart';
// import 'package:safe_drive_monitor/services/sensor_service.dart';
// import 'package:safe_drive_monitor/config/app_config.dart';
// import 'package:safe_drive_monitor/services/telegram_service.dart';
// import 'package:safe_drive_monitor/services/background_service.dart';
// import 'package:safe_drive_monitor/pages/settings_page.dart';
// import 'package:safe_drive_monitor/pages/monitoring_page.dart';
// import 'package:safe_drive_monitor/pages/drive_list_page.dart';
// import 'package:safe_drive_monitor/pages/login_page.dart';
// import 'package:safe_drive_monitor/pages/dashboard_page.dart';
// import 'package:safe_drive_monitor/services/auth_service.dart';
// import 'package:flutter_dotenv/flutter_dotenv.dart';
// import 'package:flutter/foundation.dart';
// import 'dart:math';

// void main() async {
//   WidgetsFlutterBinding.ensureInitialized();
//   await dotenv.load();
//   await AppConfig.init();
//   await AppConfig.loadSettings();
//   debugPrint = (String? message, {int? wrapWidth}) {
//     if (message?.contains('SDM_LOG:') ?? false) {
//       print(message);
//     }
//   };
//   runApp(const MyApp());
// }

// class MyApp extends StatefulWidget {
//   const MyApp({super.key});

//   @override
//   State<MyApp> createState() => _MyAppState();
// }

// class _MyAppState extends State<MyApp> {
//   bool _isAuthenticated = false;
//   bool _isLoading = true;

//   @override
//   void initState() {
//     super.initState();
//     _checkAuthentication();
//   }

//   Future<void> _checkAuthentication() async {
//     final isAuthenticated = await AuthService.isAuthenticated();
//     setState(() {
//       _isAuthenticated = isAuthenticated;
//       _isLoading = false;
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     if (_isLoading) {
//       return const MaterialApp(
//         home: Scaffold(
//           backgroundColor: Color(0xFF050508),
//           body: Center(
//             child: CircularProgressIndicator(
//               color: Color(0xFF00D4FF),
//             ),
//           ),
//         ),
//       );
//     }

//     return MaterialApp(
//       title: 'Safe Drive Monitor',
//       debugShowCheckedModeBanner: false,
//       theme: ThemeData(
//         brightness: Brightness.dark,
//         primaryColor: const Color(0xFF00D4FF),
//         scaffoldBackgroundColor: const Color(0xFF050508),
//         appBarTheme: const AppBarTheme(
//           backgroundColor: Color(0xFF050508),
//           elevation: 0,
//         ),
//         elevatedButtonTheme: ElevatedButtonThemeData(
//           style: ElevatedButton.styleFrom(
//             backgroundColor: const Color(0xFF00D4FF),
//             foregroundColor: Colors.white,
//             padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
//             shape: RoundedRectangleBorder(
//               borderRadius: BorderRadius.circular(12),
//             ),
//           ),
//         ),
//         inputDecorationTheme: InputDecorationTheme(
//           filled: true,
//           fillColor: const Color(0xFF0C0C14),
//           border: OutlineInputBorder(
//             borderRadius: BorderRadius.circular(12),
//             borderSide: BorderSide.none,
//           ),
//           enabledBorder: OutlineInputBorder(
//             borderRadius: BorderRadius.circular(12),
//             borderSide: BorderSide.none,
//           ),
//           focusedBorder: OutlineInputBorder(
//             borderRadius: BorderRadius.circular(12),
//             borderSide: const BorderSide(color: Color(0xFF00D4FF), width: 2),
//           ),
//           labelStyle: const TextStyle(color: Colors.grey),
//           hintStyle: const TextStyle(color: Colors.grey),
//         ),
//         useMaterial3: true,
//       ),
//       // -- Login ke baad seedha HUD DashboardPage khulega --
//       home: _isAuthenticated
//           ? const DashboardPage()
//           : const LoginPage(),
//     );
//   }
// }

// // -----------------------------------------------------------------------------
// //  OLD HOME PAGE � navigable from DashboardPage if needed
// // -----------------------------------------------------------------------------
// class MyHomePage extends StatefulWidget {
//   const MyHomePage({super.key, required this.title});

//   final String title;

//   @override
//   State<MyHomePage> createState() => _MyHomePageState();
// }

// class _MyHomePageState extends State<MyHomePage> {
//   final SensorService _sensorService = SensorService();
//   final TelegramService _telegramService = TelegramService();

//   double _totalAcceleration = 0.0;
//   double _currentSpeed = 0.0;
//   double _latitude = 0.0;
//   double _longitude = 0.0;
//   double _totalDistance = 0.0;
//   DateTime _startTime = DateTime.now();

//   @override
//   void initState() {
//     super.initState();
//     AppConfig.loadSettings();
//     _requestPermissions();
//     _initializeLocationUpdates();
//     _initializeAccelerometer();
//     BackgroundService.startService();
//   }

//   Future<void> _requestPermissions() async {
//     var permissionStatus = await Permission.location.request();
//     if (permissionStatus.isDenied) {
//       print("Location permission is denied. Requesting permission...");
//     }
//     await Permission.activityRecognition.request();
//     await Permission.sensors.request();
//     await Permission.camera.request();
//     await Geolocator.requestPermission();
//   }

//   void _initializeAccelerometer() {
//     accelerometerEvents.listen((AccelerometerEvent event) async {
//       if (!mounted) return;
//       setState(() {
//         _totalAcceleration = sqrt(
//             event.x * event.x + event.y * event.y + event.z * event.z);
//       });
//       if (_currentSpeed > 0) {
//         await _checkAndSendAlerts(event, _currentSpeed);
//       }
//     });
//   }

//   Future<void> _checkAndSendAlerts(
//       AccelerometerEvent event, double speed) async {
//     if (speed > AppConfig.effectiveSpeedThreshold) {
//       await _telegramService.sendSpeedAlert(speed);
//     }
//     if (_sensorService.isSuddenAcceleration(event)) {
//       await _telegramService.sendSuddenEventAlert(
//           'acceleration', _totalAcceleration);
//     }
//     if (_sensorService.isSuddenBraking(event)) {
//       await _telegramService.sendSuddenEventAlert(
//           'braking', _totalAcceleration);
//     }
//     if (_sensorService.isSharpTurn(event)) {
//       await _telegramService.sendSuddenEventAlert('turn', _totalAcceleration);
//     }
//   }

//   void _log(String message) {
//     if (kDebugMode) {
//       print('SDM_LOG: $message');
//     }
//   }

//   void _initializeLocationUpdates() async {
//     bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
//     if (!serviceEnabled) {
//       _log('Location services are disabled');
//       return;
//     }
//     LocationPermission permission = await Geolocator.checkPermission();
//     if (permission == LocationPermission.denied) {
//       permission = await Geolocator.requestPermission();
//       if (permission == LocationPermission.denied) {
//         _log('Location permissions are denied');
//         return;
//       }
//     }
//     Geolocator.getPositionStream(
//       locationSettings: const LocationSettings(
//         accuracy: LocationAccuracy.high,
//         distanceFilter: 1,
//       ),
//     ).listen((Position position) {
//       final distanceInMeters = Geolocator.distanceBetween(
//         _latitude,
//         _longitude,
//         position.latitude,
//         position.longitude,
//       );
//       setState(() {
//         _totalDistance += distanceInMeters;
//         _latitude = position.latitude;
//         _longitude = position.longitude;
//         _currentSpeed = position.speed <= 0
//             ? 0.0
//             : (position.speed * 3.6).clamp(0, 200);
//       });
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     final duration = DateTime.now().difference(_startTime);

//     return Scaffold(
//       backgroundColor: Colors.black,
//       body: SafeArea(
//         child: Stack(
//           children: [
//             Center(
//               child: Column(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   TweenAnimationBuilder(
//                     tween: Tween<double>(begin: 0, end: _currentSpeed),
//                     duration: const Duration(milliseconds: 500),
//                     builder: (context, double speed, child) {
//                       return Container(
//                         width: 200,
//                         height: 200,
//                         decoration: BoxDecoration(
//                           shape: BoxShape.circle,
//                           color: Colors.grey[900],
//                         ),
//                         child: Stack(
//                           children: [
//                             CircularProgressIndicator(
//                               value: (_currentSpeed / 200).clamp(0.0, 1.0),
//                               strokeWidth: 15,
//                               backgroundColor: Colors.grey[800],
//                               color: _currentSpeed > 120
//                                   ? Colors.red
//                                   : Colors.green,
//                             ),
//                             Center(
//                               child: Text(
//                                 '${speed.toStringAsFixed(0)} km/h',
//                                 style: const TextStyle(
//                                   fontSize: 36,
//                                   fontWeight: FontWeight.bold,
//                                   color: Colors.white,
//                                 ),
//                               ),
//                             ),
//                           ],
//                         ),
//                       );
//                     },
//                   ),
//                   const SizedBox(height: 30),
//                   Container(
//                     padding: const EdgeInsets.symmetric(
//                         horizontal: 16, vertical: 8),
//                     decoration: BoxDecoration(
//                       color: Colors.grey[900],
//                       borderRadius: BorderRadius.circular(20),
//                       border: Border.all(
//                         color: _currentSpeed >
//                                 AppConfig.effectiveSpeedThreshold
//                             ? Colors.red
//                             : Colors.grey,
//                         width: 1,
//                       ),
//                     ),
//                     child: Row(
//                       mainAxisSize: MainAxisSize.min,
//                       children: [
//                         Icon(
//                           Icons.speed,
//                           color: _currentSpeed >
//                                   AppConfig.effectiveSpeedThreshold
//                               ? Colors.red
//                               : Colors.grey[400],
//                         ),
//                         const SizedBox(width: 8),
//                         Text(
//                           'Speed Limit: ${AppConfig.effectiveSpeedThreshold.toStringAsFixed(0)} km/h',
//                           style: TextStyle(
//                             color: _currentSpeed >
//                                     AppConfig.effectiveSpeedThreshold
//                                 ? Colors.red
//                                 : Colors.grey[400],
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                   const SizedBox(height: 40),
//                   Container(
//                     padding: const EdgeInsets.symmetric(
//                         horizontal: 16, vertical: 8),
//                     decoration: BoxDecoration(
//                       color: Colors.grey[900]?.withOpacity(0.5),
//                       borderRadius: BorderRadius.circular(15),
//                     ),
//                     child: Text(
//                       'Lat: ${_latitude.toStringAsFixed(5)}, Lon: ${_longitude.toStringAsFixed(5)}',
//                       style:
//                           TextStyle(color: Colors.grey[600], fontSize: 12),
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//             Positioned(
//               left: 0,
//               bottom: 0,
//               right: 0,
//               child: DrivingSummary(
//                 totalDistance: _totalDistance,
//                 drivingTime: duration,
//               ),
//             ),
//             Positioned(
//               right: 16,
//               bottom: 16,
//               child: Column(
//                 mainAxisSize: MainAxisSize.min,
//                 children: [
//                   FloatingActionButton(
//                     mini: true,
//                     backgroundColor: Colors.grey[900],
//                     child: const Icon(Icons.history, color: Colors.white),
//                     onPressed: () {
//                       Navigator.push(
//                         context,
//                         MaterialPageRoute(
//                             builder: (context) => const DriveListPage()),
//                       );
//                     },
//                   ),
//                   const SizedBox(height: 8),
//                   FloatingActionButton(
//                     mini: true,
//                     backgroundColor: Colors.grey[900],
//                     child:
//                         const Icon(Icons.settings, color: Colors.white),
//                     onPressed: () {
//                       Navigator.push(
//                         context,
//                         MaterialPageRoute(
//                             builder: (context) => const SettingsPage()),
//                       );
//                     },
//                   ),
//                   const SizedBox(height: 8),
//                   FloatingActionButton(
//                     mini: true,
//                     backgroundColor: Colors.grey[900],
//                     child: const Icon(Icons.remove_red_eye,
//                         color: Colors.white),
//                     onPressed: () {
//                       Navigator.push(
//                         context,
//                         MaterialPageRoute(
//                             builder: (context) => const MonitoringPage()),
//                       );
//                     },
//                   ),
//                 ],
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

// class DrivingSummary extends StatelessWidget {
//   final double totalDistance;
//   final Duration drivingTime;

//   const DrivingSummary({
//     Key? key,
//     required this.totalDistance,
//     required this.drivingTime,
//   }) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       padding: const EdgeInsets.all(16),
//       decoration: BoxDecoration(
//         color: Colors.grey[900]?.withOpacity(0.7),
//         borderRadius: BorderRadius.circular(20),
//       ),
//       child: Column(
//         mainAxisSize: MainAxisSize.min,
//         children: [
//           const Text(
//             'Driving Summary',
//             style: TextStyle(
//               fontSize: 20,
//               fontWeight: FontWeight.bold,
//               color: Colors.white,
//             ),
//           ),
//           const SizedBox(height: 8),
//           Text(
//             'Total Distance: ${_formatDistance(totalDistance)}',
//             style: TextStyle(color: Colors.grey[400], fontSize: 16),
//           ),
//           const SizedBox(height: 8),
//           Text(
//             'Driving Time: ${_formatDuration(drivingTime)}',
//             style: TextStyle(color: Colors.grey[400], fontSize: 16),
//           ),
//         ],
//       ),
//     );
//   }

//   String _formatDistance(double distance) {
//     if (distance >= 1000) {
//       return '${(distance / 1000).toStringAsFixed(2)} km';
//     } else {
//       return '${distance.toStringAsFixed(0)} m';
//     }
//   }

//   String _formatDuration(Duration duration) {
//     final hours = duration.inHours;
//     final minutes = duration.inMinutes % 60;
//     final seconds = duration.inSeconds % 60;
//     return '${hours.toString().padLeft(2, '0')}:${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
//   }
// }










import 'package:flutter/material.dart';
import 'package:sensors_plus/sensors_plus.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:safe_drive_monitor/services/sensor_service.dart';
import 'package:safe_drive_monitor/config/app_config.dart';
import 'package:safe_drive_monitor/services/telegram_service.dart';
import 'package:safe_drive_monitor/services/background_service.dart';
import 'package:safe_drive_monitor/pages/settings_page.dart';
import 'package:safe_drive_monitor/pages/monitoring_page.dart';
import 'package:safe_drive_monitor/pages/drive_list_page.dart';
import 'package:safe_drive_monitor/pages/login_page.dart';
import 'package:safe_drive_monitor/pages/dashboard_page.dart';
import 'package:safe_drive_monitor/services/auth_service.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter/foundation.dart';
import 'dart:math';
import 'package:safe_drive_monitor/services/firebase_test.dart';

import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
   await FirebaseTest.testConnection();
  await dotenv.load();
  await AppConfig.init();
  await AppConfig.loadSettings();

  debugPrint = (String? message, {int? wrapWidth}) {
    if (message?.contains('SDM_LOG:') ?? false) {
      print(message);
    }
  };

  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  bool _isAuthenticated = false;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _checkAuthentication();
  }

  Future<void> _checkAuthentication() async {
    final isAuthenticated = await AuthService.isAuthenticated();
    setState(() {
      _isAuthenticated = isAuthenticated;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const MaterialApp(
        home: Scaffold(
          backgroundColor: Color(0xFF050508),
          body: Center(
            child: CircularProgressIndicator(
              color: Color(0xFF00D4FF),
            ),
          ),
        ),
      );
    }

    return MaterialApp(
      title: 'Safe Drive Monitor',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        primaryColor: const Color(0xFF00D4FF),
        scaffoldBackgroundColor: const Color(0xFF050508),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF050508),
          elevation: 0,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF00D4FF),
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFF0C0C14),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: Color(0xFF00D4FF), width: 2),
          ),
          labelStyle: const TextStyle(color: Colors.grey),
          hintStyle: const TextStyle(color: Colors.grey),
        ),
        useMaterial3: true,
      ),
      // -- Login ke baad seedha HUD DashboardPage khulega --
      home: _isAuthenticated
          ? const DashboardPage()
          : const LoginPage(),
    );
  }
}

// -----------------------------------------------------------------------------
//  OLD HOME PAGE � navigable from DashboardPage if needed
// -----------------------------------------------------------------------------
class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final SensorService _sensorService = SensorService();
  final TelegramService _telegramService = TelegramService();

  double _totalAcceleration = 0.0;
  double _currentSpeed = 0.0;
  double _latitude = 0.0;
  double _longitude = 0.0;
  double _totalDistance = 0.0;
  DateTime _startTime = DateTime.now();

  @override
  void initState() {
    super.initState();
    AppConfig.loadSettings();
    _requestPermissions();
    _initializeLocationUpdates();
    _initializeAccelerometer();
    BackgroundService.startService();
  }

  Future<void> _requestPermissions() async {
    var permissionStatus = await Permission.location.request();
    if (permissionStatus.isDenied) {
      print("Location permission is denied. Requesting permission...");
    }
    await Permission.activityRecognition.request();
    await Permission.sensors.request();
    await Permission.camera.request();
    await Geolocator.requestPermission();
  }

  void _initializeAccelerometer() {
    accelerometerEvents.listen((AccelerometerEvent event) async {
      if (!mounted) return;
      setState(() {
        _totalAcceleration = sqrt(
            event.x * event.x + event.y * event.y + event.z * event.z);
      });
      if (_currentSpeed > 0) {
        await _checkAndSendAlerts(event, _currentSpeed);
      }
    });
  }

  Future<void> _checkAndSendAlerts(
      AccelerometerEvent event, double speed) async {
    if (speed > AppConfig.effectiveSpeedThreshold) {
      await _telegramService.sendSpeedAlert(speed);
    }
    if (_sensorService.isSuddenAcceleration(event)) {
      await _telegramService.sendSuddenEventAlert(
          'acceleration', _totalAcceleration);
    }
    if (_sensorService.isSuddenBraking(event)) {
      await _telegramService.sendSuddenEventAlert(
          'braking', _totalAcceleration);
    }
    if (_sensorService.isSharpTurn(event)) {
      await _telegramService.sendSuddenEventAlert('turn', _totalAcceleration);
    }
  }

  void _log(String message) {
    if (kDebugMode) {
      print('SDM_LOG: $message');
    }
  }

  void _initializeLocationUpdates() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      _log('Location services are disabled');
      return;
    }
    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        _log('Location permissions are denied');
        return;
      }
    }
    Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 1,
      ),
    ).listen((Position position) {
      final distanceInMeters = Geolocator.distanceBetween(
        _latitude,
        _longitude,
        position.latitude,
        position.longitude,
      );
      setState(() {
        _totalDistance += distanceInMeters;
        _latitude = position.latitude;
        _longitude = position.longitude;
        _currentSpeed = position.speed <= 0
            ? 0.0
            : (position.speed * 3.6).clamp(0, 200);
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final duration = DateTime.now().difference(_startTime);

    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Stack(
          children: [
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  TweenAnimationBuilder(
                    tween: Tween<double>(begin: 0, end: _currentSpeed),
                    duration: const Duration(milliseconds: 500),
                    builder: (context, double speed, child) {
                      return Container(
                        width: 200,
                        height: 200,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.grey[900],
                        ),
                        child: Stack(
                          children: [
                            CircularProgressIndicator(
                              value: (_currentSpeed / 200).clamp(0.0, 1.0),
                              strokeWidth: 15,
                              backgroundColor: Colors.grey[800],
                              color: _currentSpeed > 120
                                  ? Colors.red
                                  : Colors.green,
                            ),
                            Center(
                              child: Text(
                                '${speed.toStringAsFixed(0)} km/h',
                                style: const TextStyle(
                                  fontSize: 36,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 30),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                      color: Colors.grey[900],
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: _currentSpeed >
                                AppConfig.effectiveSpeedThreshold
                            ? Colors.red
                            : Colors.grey,
                        width: 1,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.speed,
                          color: _currentSpeed >
                                  AppConfig.effectiveSpeedThreshold
                              ? Colors.red
                              : Colors.grey[400],
                        ),
                        const SizedBox(width: 8),
                        Text(
                          'Speed Limit: ${AppConfig.effectiveSpeedThreshold.toStringAsFixed(0)} km/h',
                          style: TextStyle(
                            color: _currentSpeed >
                                    AppConfig.effectiveSpeedThreshold
                                ? Colors.red
                                : Colors.grey[400],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 40),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                      color: Colors.grey[900]?.withOpacity(0.5),
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: Text(
                      'Lat: ${_latitude.toStringAsFixed(5)}, Lon: ${_longitude.toStringAsFixed(5)}',
                      style:
                          TextStyle(color: Colors.grey[600], fontSize: 12),
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              left: 0,
              bottom: 0,
              right: 0,
              child: DrivingSummary(
                totalDistance: _totalDistance,
                drivingTime: duration,
              ),
            ),
            Positioned(
              right: 16,
              bottom: 16,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  FloatingActionButton(
                    mini: true,
                    backgroundColor: Colors.grey[900],
                    child: const Icon(Icons.history, color: Colors.white),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const DriveListPage()),
                      );
                    },
                  ),
                  const SizedBox(height: 8),
                  FloatingActionButton(
                    mini: true,
                    backgroundColor: Colors.grey[900],
                    child:
                        const Icon(Icons.settings, color: Colors.white),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const SettingsPage()),
                      );
                    },
                  ),
                  const SizedBox(height: 8),
                  FloatingActionButton(
                    mini: true,
                    backgroundColor: Colors.grey[900],
                    child: const Icon(Icons.remove_red_eye,
                        color: Colors.white),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const MonitoringPage()),
                      );
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class DrivingSummary extends StatelessWidget {
  final double totalDistance;
  final Duration drivingTime;

  const DrivingSummary({
    Key? key,
    required this.totalDistance,
    required this.drivingTime,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[900]?.withOpacity(0.7),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text(
            'Driving Summary',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Total Distance: ${_formatDistance(totalDistance)}',
            style: TextStyle(color: Colors.grey[400], fontSize: 16),
          ),
          const SizedBox(height: 8),
          Text(
            'Driving Time: ${_formatDuration(drivingTime)}',
            style: TextStyle(color: Colors.grey[400], fontSize: 16),
          ),
        ],
      ),
    );
  }

  String _formatDistance(double distance) {
    if (distance >= 1000) {
      return '${(distance / 1000).toStringAsFixed(2)} km';
    } else {
      return '${distance.toStringAsFixed(0)} m';
    }
  }

  String _formatDuration(Duration duration) {
    final hours = duration.inHours;
    final minutes = duration.inMinutes % 60;
    final seconds = duration.inSeconds % 60;
    return '${hours.toString().padLeft(2, '0')}:${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
  }
}
