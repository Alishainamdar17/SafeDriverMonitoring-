import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/drive.dart';
  
class FirebaseDriveService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // ===============================
  // 1. START DRIVE
  // ===============================
  Future<String> startDrive(String userId) async {
    final doc = await _firestore
        .collection('users')
        .doc(userId)
        .collection('drives')
        .add({
      'startTime': FieldValue.serverTimestamp(),
      'status': 'active',
    });

    return doc.id; // driveId
  }

  // ===============================
  // 2. LIVE UPDATE (MONITORING DATA)
  // ===============================
  Future<void> updateLiveData(
    String userId,
    Map<String, dynamic> data,
  ) async {
    await _firestore
        .collection('users')
        .doc(userId)
        .collection('live_tracking')
        .doc('current_drive')
        .set({
      ...data,
      'timestamp': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  // ===============================
  // 3. ADD GPS ROUTE POINT
  // ===============================
  Future<void> addRoutePoint(
    String userId,
    String driveId,
    LocationPoint point,
  ) async {
    await _firestore
        .collection('users')
        .doc(userId)
        .collection('drives')
        .doc(driveId)
        .collection('route_points')
        .add(point.toFirebaseMap());
  }

  // ===============================
  // 4. END DRIVE (SAVE FINAL DATA)
  // ===============================
  Future<void> endDrive(
    String userId,
    String driveId,
    Drive drive,
  ) async {
    await _firestore
        .collection('users')
        .doc(userId)
        .collection('drives')
        .doc(driveId)
        .set(
          drive.toFirebaseMap(),
          SetOptions(merge: true),
        );
  }
}