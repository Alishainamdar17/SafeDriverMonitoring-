// lib/services/live_drive_state.dart
// ─────────────────────────────────────────────────────────────────────────────
// Singleton that holds ALL live drive metrics.
// DashboardPage writes to it; AnalyticsPage & DriveHistoryPage read from it.
// ─────────────────────────────────────────────────────────────────────────────
import 'package:flutter/foundation.dart';

class LiveDriveSession {
  final DateTime startTime;
  final String startLocation;
  double distanceMeters;
  double currentSpeed;
  double maxSpeed;
  double avgSpeed;
  int speedSamples;
  int hardBrakeCount;
  int hardAccelCount;
  int sharpTurnCount;
  int overSpeedCount;
  double safetyScore;
  bool isActive;

  // For history entry
  String endLocation;
  DateTime? endTime;

  LiveDriveSession({
    required this.startTime,
    required this.startLocation,
    this.distanceMeters = 0,
    this.currentSpeed = 0,
    this.maxSpeed = 0,
    this.avgSpeed = 0,
    this.speedSamples = 0,
    this.hardBrakeCount = 0,
    this.hardAccelCount = 0,
    this.sharpTurnCount = 0,
    this.overSpeedCount = 0,
    this.safetyScore = 100,
    this.isActive = true,
    this.endLocation = '',
    this.endTime,
  });

  Duration get duration =>
      (endTime ?? DateTime.now()).difference(startTime);

  double get distanceKm => distanceMeters / 1000;

  String get grade {
    if (safetyScore >= 90) return 'A+';
    if (safetyScore >= 80) return 'A';
    if (safetyScore >= 70) return 'B';
    if (safetyScore >= 55) return 'C';
    return 'D';
  }
}

class LiveDriveState extends ChangeNotifier {
  // ── Singleton ──────────────────────────────────────────────────────────────
  static final LiveDriveState instance = LiveDriveState._();
  LiveDriveState._();

  // ── Current live session ───────────────────────────────────────────────────
  LiveDriveSession? _current;
  LiveDriveSession? get current => _current;
  bool get hasDrive => _current != null;

  // ── Completed session history (most recent first) ──────────────────────────
  final List<LiveDriveSession> _history = [];
  List<LiveDriveSession> get history => List.unmodifiable(_history);

  // ── Start a new drive ──────────────────────────────────────────────────────
  void startDrive(String location) {
    _current = LiveDriveSession(
      startTime: DateTime.now(),
      startLocation: location,
    );
    notifyListeners();
  }

  // ── Update live metrics every GPS tick ────────────────────────────────────
  void updateSpeed({
    required double speed,
    required double distanceDelta,
  }) {
    if (_current == null) return;
    _current!.distanceMeters += distanceDelta;
    _current!.currentSpeed = speed;
    if (speed > _current!.maxSpeed) _current!.maxSpeed = speed;
    _current!.speedSamples++;
    _current!.avgSpeed =
        (_current!.avgSpeed * (_current!.speedSamples - 1) + speed) /
            _current!.speedSamples;
    notifyListeners();
  }

  // ── Event increments ───────────────────────────────────────────────────────
  void addHardBrake() {
    if (_current == null) return;
    _current!.hardBrakeCount++;
    _deduct(5);
  }

  void addHardAccel() {
    if (_current == null) return;
    _current!.hardAccelCount++;
    _deduct(3);
  }

  void addSharpTurn() {
    if (_current == null) return;
    _current!.sharpTurnCount++;
    _deduct(4);
  }

  void addOverSpeed() {
    if (_current == null) return;
    _current!.overSpeedCount++;
    _deduct(5);
  }

  void _deduct(double amount) {
    _current!.safetyScore =
        (_current!.safetyScore - amount).clamp(0.0, 100.0);
    notifyListeners();
  }

  // ── End drive ──────────────────────────────────────────────────────────────
  void endDrive(String endLocation) {
    if (_current == null) return;
    _current!.endLocation = endLocation;
    _current!.endTime = DateTime.now();
    _current!.isActive = false;
    _history.insert(0, _current!); // newest first
    if (_history.length > 50) _history.removeLast(); // keep last 50
    _current = null;
    notifyListeners();
  }

  // ── Analytics aggregates ───────────────────────────────────────────────────
  double get allTimeAvgScore {
    if (_history.isEmpty) return 0;
    return _history.fold(0.0, (s, d) => s + d.safetyScore) / _history.length;
  }

  int get totalTrips => _history.length;

  double get totalDistanceKm =>
      _history.fold(0.0, (s, d) => s + d.distanceKm);

  Duration get totalDriveTime =>
      _history.fold(Duration.zero, (s, d) => s + d.duration);

  int get totalHardBrakes =>
      _history.fold(0, (s, d) => s + d.hardBrakeCount);

  int get totalHardAccels =>
      _history.fold(0, (s, d) => s + d.hardAccelCount);

  int get totalSharpTurns =>
      _history.fold(0, (s, d) => s + d.sharpTurnCount);

  int get totalOverSpeeds =>
      _history.fold(0, (s, d) => s + d.overSpeedCount);
}