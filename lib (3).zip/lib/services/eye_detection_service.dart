﻿// lib/services/eye_detection_service.dart
import 'package:camera/camera.dart';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
import 'dart:async';
import 'package:flutter/services.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

enum HeadMovement { straight, nodding, tiltedLeft, tiltedRight, turnedLeft, turnedRight }

class BlinkEvent {
  final DateTime timestamp;
  final int blinkCount;
  final double blinksPerMinute;
  const BlinkEvent({
    required this.timestamp,
    required this.blinkCount,
    required this.blinksPerMinute,
  });
}

class EyeDetectionData {
  final bool leftEyeOpen;
  final bool rightEyeOpen;
  final double leftEyeOpenProbability;
  final double rightEyeOpenProbability;
  final DateTime timestamp;
  final bool noFaceDetected;
  final int blinkCount;
  final double blinksPerMinute;
  final bool isBlinking;
  final double headEulerAngleX;
  final double headEulerAngleY;
  final double headEulerAngleZ;
  final HeadMovement headMovement;
  final bool isHeadDropping;

  const EyeDetectionData({
    required this.leftEyeOpen,
    required this.rightEyeOpen,
    required this.leftEyeOpenProbability,
    required this.rightEyeOpenProbability,
    required this.timestamp,
    this.noFaceDetected = false,
    this.blinkCount = 0,
    this.blinksPerMinute = 0.0,
    this.isBlinking = false,
    this.headEulerAngleX = 0.0,
    this.headEulerAngleY = 0.0,
    this.headEulerAngleZ = 0.0,
    this.headMovement = HeadMovement.straight,
    this.isHeadDropping = false,
  });

  bool get bothEyesOpen => leftEyeOpen && rightEyeOpen;
  bool get bothEyesClosed => !leftEyeOpen && !rightEyeOpen;
  bool get oneEyeClosed =>
      (leftEyeOpen && !rightEyeOpen) || (!leftEyeOpen && rightEyeOpen);
  bool get isHighBlinkRate => blinksPerMinute > 25.0;

  String get headMovementLabel {
    switch (headMovement) {
      case HeadMovement.straight:     return 'Head Straight';
      case HeadMovement.nodding:      return '⚠️ Head Dropping';
      case HeadMovement.tiltedLeft:   return '⚠️ Tilted Left';
      case HeadMovement.tiltedRight:  return '⚠️ Tilted Right';
      case HeadMovement.turnedLeft:   return '⚡ Turned Left';
      case HeadMovement.turnedRight:  return '⚡ Turned Right';
    }
  }

  String get status {
    if (noFaceDetected) return '📷 No face detected - position your face';
    if (isHeadDropping) return '🆘 HEAD DROPPING - Drowsy!';
    if (bothEyesClosed) return '⚠️ DROWSY - Both eyes closed!';
    if (oneEyeClosed)   return '⚡ WARNING - One eye closed';
    if (headMovement != HeadMovement.straight) return headMovementLabel;
    if (bothEyesOpen)   return '✅ ALERT - Both eyes open';
    return 'Waiting for face...';
  }

  int get safetyLevel {
    if (noFaceDetected) return 50;
    if (isHeadDropping || bothEyesClosed) return 0;
    if (oneEyeClosed) return 30;
    if (headMovement == HeadMovement.nodding) return 10;
    if (headMovement == HeadMovement.tiltedLeft ||
        headMovement == HeadMovement.tiltedRight) return 40;
    if (headMovement == HeadMovement.turnedLeft ||
        headMovement == HeadMovement.turnedRight) return 60;
    if (isHighBlinkRate) return 70;
    if (bothEyesOpen) return 100;
    return 50;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  EYE DETECTION SERVICE
//  Alert sound: ambulance siren (assets/sounds/ambulance_siren.mp3)
//  Add the file to your pubspec.yaml under flutter > assets:
//    - assets/sounds/ambulance_siren.mp3
//  Download a royalty-free ambulance siren from mixkit.co or freesound.org
// ─────────────────────────────────────────────────────────────────────────────
class EyeDetectionService {
  // ── Face detector ──────────────────────────────────────────────────────────
  final FaceDetector _faceDetector = FaceDetector(
    options: FaceDetectorOptions(
      enableClassification: true,
      enableLandmarks: true,
      enableContours: true,
      enableTracking: true,
      performanceMode: FaceDetectorMode.accurate,
    ),
  );

  // ── TTS (stub) ─────────────────────────────────────────────────────────────
  // flutter_tts not in pubspec — voice alerts logged to console.
  // Add flutter_tts: ^4.0.0 to pubspec.yaml to enable real voice.
  String _lastSpokenAlert = '';
  static const Duration _alertCooldown = Duration(seconds: 4);
  DateTime _lastAlertTime = DateTime.fromMillisecondsSinceEpoch(0);

  // ── Drowsiness frame counter ───────────────────────────────────────────────
  static const int _drowsyFrameThreshold = 10;
  int _drowsyFrameCount = 0;

  // ── Blink tracking ─────────────────────────────────────────────────────────
  bool _eyesWereClosed = false;
  int _totalBlinkCount = 0;
  final List<DateTime> _blinkTimestamps = [];
  static const Duration _blinkRateWindow = Duration(minutes: 1);

  final StreamController<BlinkEvent> _blinkEventStream =
      StreamController<BlinkEvent>.broadcast();
  Stream<BlinkEvent> get blinkEventStream => _blinkEventStream.stream;

  // ── Head movement thresholds ───────────────────────────────────────────────
  static const double _headDropThreshold  = -20.0;
  static const double _headTiltThreshold  =  20.0;
  static const double _headTurnThreshold  =  30.0;
  static const int    _headDropFrameThreshold = 8;
  int _headDropFrameCount = 0;

  // ── Camera ─────────────────────────────────────────────────────────────────
  late CameraController    _cameraController;
  late CameraDescription   _cameraDescription;
  final StreamController<EyeDetectionData> _eyeDetectionStream =
      StreamController<EyeDetectionData>.broadcast();
  bool _isDetecting = false;

  Stream<EyeDetectionData> get eyeDetectionStream => _eyeDetectionStream.stream;
  CameraController         get cameraController   => _cameraController;

  // ── Ambulance siren via MethodChannel → MainActivity.kt RingtoneManager ──
  // Uses Android RingtoneManager.TYPE_ALARM — plays device default alarm siren.
  // No MP3 file needed. MainActivity.kt must handle 'siren/play' and 'siren/stop'.
  static const MethodChannel _sirenChannel = MethodChannel('safe_drive/siren');
  bool _isAlarmPlaying = false;

  // ── Init ───────────────────────────────────────────────────────────────────
  Future<void> initialize(List<CameraDescription> cameras) async {
    final status = await Permission.camera.request();
    if (!status.isGranted) throw Exception('Camera permission not granted');

    // TTS setup — flutter_tts stub (add to pubspec.yaml to enable voice)

    // Camera selection — prefer front camera
    try {
      _cameraDescription = cameras.firstWhere(
        (c) => c.lensDirection == CameraLensDirection.front,
      );
    } catch (_) {
      _cameraDescription = cameras.first;
    }

    _cameraController = CameraController(
      _cameraDescription,
      ResolutionPreset.low,
      enableAudio: false,
      imageFormatGroup: ImageFormatGroup.nv21,
    );

    await _cameraController.initialize();



    _startEyeDetection();
  }

  // ── Detection loop ─────────────────────────────────────────────────────────
  void _startEyeDetection() {
    _cameraController.startImageStream((image) async {
      if (_isDetecting) return;
      _isDetecting = true;
      try {
        await _detectEyes(image);
      } catch (e) {
        debugPrint('Stream error: $e');
      } finally {
        _isDetecting = false;
      }
    });
  }

  Future<void> _detectEyes(CameraImage image) async {
    final inputImage = _convertCameraImageToInputImage(image);
    if (inputImage == null) return;

    try {
      final faces = await _faceDetector.processImage(inputImage);

      if (faces.isNotEmpty) {
        final face = faces.first;
        final leftEyeOpen  = face.leftEyeOpenProbability  ?? 0.0;
        final rightEyeOpen = face.rightEyeOpenProbability ?? 0.0;
        final eyesCurrentlyClosed = leftEyeOpen < 0.5 && rightEyeOpen < 0.5;

        // ── Blink detection (closed → open transition) ─────────────────────
        bool justBlinked = false;
        if (_eyesWereClosed && !eyesCurrentlyClosed) {
          _totalBlinkCount++;
          justBlinked = true;
          final now = DateTime.now();
          _blinkTimestamps.add(now);
          _blinkTimestamps.removeWhere(
            (t) => now.difference(t) > _blinkRateWindow,
          );
          _blinkEventStream.add(BlinkEvent(
            timestamp: now,
            blinkCount: _totalBlinkCount,
            blinksPerMinute: _blinkTimestamps.length.toDouble(),
          ));
          debugPrint(
            'BLINK #$_totalBlinkCount | BPM: ${_blinkTimestamps.length}',
          );
        }
        _eyesWereClosed = eyesCurrentlyClosed;

        // ── Head euler angles ──────────────────────────────────────────────
        final eulerX = face.headEulerAngleX ?? 0.0;
        final eulerY = face.headEulerAngleY ?? 0.0;
        final eulerZ = face.headEulerAngleZ ?? 0.0;

        final headMovement = _classifyHeadMovement(eulerX, eulerY, eulerZ);

        // ── Head drop frame accumulator ────────────────────────────────────
        if (eulerX < _headDropThreshold) {
          _headDropFrameCount++;
        } else {
          _headDropFrameCount = 0;
        }
        final isHeadDropping = _headDropFrameCount >= _headDropFrameThreshold;

        final now = DateTime.now();
        _blinkTimestamps.removeWhere(
          (t) => now.difference(t) > _blinkRateWindow,
        );

        debugPrint(
          'EYES L:${leftEyeOpen.toStringAsFixed(2)} '
          'R:${rightEyeOpen.toStringAsFixed(2)} | '
          'EulerX:${eulerX.toStringAsFixed(1)} '
          'Y:${eulerY.toStringAsFixed(1)} '
          'Z:${eulerZ.toStringAsFixed(1)} | '
          'Movement: $headMovement',
        );

        final data = EyeDetectionData(
          leftEyeOpen: leftEyeOpen > 0.5,
          rightEyeOpen: rightEyeOpen > 0.5,
          leftEyeOpenProbability: leftEyeOpen,
          rightEyeOpenProbability: rightEyeOpen,
          timestamp: now,
          noFaceDetected: false,
          blinkCount: _totalBlinkCount,
          blinksPerMinute: _blinkTimestamps.length.toDouble(),
          isBlinking: justBlinked,
          headEulerAngleX: eulerX,
          headEulerAngleY: eulerY,
          headEulerAngleZ: eulerZ,
          headMovement: headMovement,
          isHeadDropping: isHeadDropping,
        );

        _eyeDetectionStream.add(data);
        _handleVoiceAlert(data);
      } else {
        // No face detected — reset counters, stop alarm
        _drowsyFrameCount = 0;
        _headDropFrameCount = 0;
        _eyesWereClosed = false;
        _eyeDetectionStream.add(EyeDetectionData(
          leftEyeOpen: false,
          rightEyeOpen: false,
          leftEyeOpenProbability: 0.0,
          rightEyeOpenProbability: 0.0,
          timestamp: DateTime.now(),
          noFaceDetected: true,
          blinkCount: _totalBlinkCount,
          blinksPerMinute: _blinkTimestamps.length.toDouble(),
        ));
        if (_isAlarmPlaying) await _stopAlarm();
      }
    } catch (e, stack) {
      debugPrint('Detection error: $e\n$stack');
    }
  }

  // ── Head movement classifier ───────────────────────────────────────────────
  HeadMovement _classifyHeadMovement(
      double eulerX, double eulerY, double eulerZ) {
    if (eulerX < _headDropThreshold) return HeadMovement.nodding;
    if (eulerZ >  _headTiltThreshold) return HeadMovement.tiltedRight;
    if (eulerZ < -_headTiltThreshold) return HeadMovement.tiltedLeft;
    if (eulerY >  _headTurnThreshold) return HeadMovement.turnedRight;
    if (eulerY < -_headTurnThreshold) return HeadMovement.turnedLeft;
    return HeadMovement.straight;
  }

  // ── Alert handler ──────────────────────────────────────────────────────────
  void _handleVoiceAlert(EyeDetectionData data) {
    final now = DateTime.now();
    final cooldownPassed = now.difference(_lastAlertTime) > _alertCooldown;

    // ── CRITICAL: Head dropping → ambulance siren + voice ──────────────────
    if (data.isHeadDropping) {
      if (!_isAlarmPlaying) _playAmbulanceSiren();
      if (cooldownPassed) {
        _speakAlert('Danger! Your head is dropping. You are falling asleep!');
        _lastAlertTime = now;
      }
      _drowsyFrameCount = 0;
      return;
    }

    // ── CRITICAL: Both eyes closed for N frames → ambulance siren + voice ──
    if (data.bothEyesClosed) {
      _drowsyFrameCount++;
      if (_drowsyFrameCount >= _drowsyFrameThreshold) {
        if (!_isAlarmPlaying) _playAmbulanceSiren();
        if (cooldownPassed) {
          _speakAlert('Warning! You are drowsy. Please pull over and rest.');
          _lastAlertTime = now;
        }
      }
      return;
    }

    // Driver is no longer drowsy — stop alarm
    _drowsyFrameCount = 0;
    if (_isAlarmPlaying) _stopAlarm();

    // ── Mild alerts (voice only, no siren) ─────────────────────────────────
    if (data.oneEyeClosed &&
        _lastSpokenAlert != 'one_eye' &&
        cooldownPassed) {
      _speakAlert('Caution! One eye closed. Stay alert.');
      _lastAlertTime = now;
      _lastSpokenAlert = 'one_eye';
      return;
    }

    if ((data.headMovement == HeadMovement.tiltedLeft ||
            data.headMovement == HeadMovement.tiltedRight) &&
        _lastSpokenAlert != 'tilt' &&
        cooldownPassed) {
      _speakAlert('Warning! Your head is tilting. Stay focused.');
      _lastAlertTime = now;
      _lastSpokenAlert = 'tilt';
      return;
    }

    if ((data.headMovement == HeadMovement.turnedLeft ||
            data.headMovement == HeadMovement.turnedRight) &&
        _lastSpokenAlert != 'turn' &&
        cooldownPassed) {
      _speakAlert('Keep your eyes on the road!');
      _lastAlertTime = now;
      _lastSpokenAlert = 'turn';
      return;
    }

    if (data.isHighBlinkRate &&
        _lastSpokenAlert != 'blink_rate' &&
        cooldownPassed) {
      _speakAlert(
        'High blink rate detected. You may be fatigued. Consider taking a break.',
      );
      _lastAlertTime = now;
      _lastSpokenAlert = 'blink_rate';
      return;
    }

    // All clear — reset alert tracker
    if (data.bothEyesOpen && data.headMovement == HeadMovement.straight) {
      _lastSpokenAlert = '';
    }
  }

  // ── Ambulance siren via RingtoneManager (MethodChannel) ──────────────────
  //  Calls MainActivity.kt which uses Android RingtoneManager.TYPE_ALARM.
  //  This plays the device's built-in alarm siren — loud, no MP3 needed.
  Future<void> _playAmbulanceSiren() async {
    try {
      if (_isAlarmPlaying) return;
      _isAlarmPlaying = true;
      await _sirenChannel.invokeMethod('play');
      debugPrint('🚑 Ambulance siren STARTED via RingtoneManager');
    } catch (e) {
      debugPrint('Siren channel error: $e');
      _isAlarmPlaying = false;
      HapticFeedback.heavyImpact();
      await _speakAlert('DANGER! WAKE UP! Pull over NOW!');
    }
  }

  Future<void> _stopAlarm() async {
    try {
      if (!_isAlarmPlaying) return;
      await _sirenChannel.invokeMethod('stop');
      _isAlarmPlaying = false;
      debugPrint('🔕 Ambulance siren STOPPED');
    } catch (e) {
      debugPrint('Alarm stop error: $e');
    }
  }

  // ── Voice alert helper ─────────────────────────────────────────────────────
  // flutter_tts not in pubspec — logged to console + haptic feedback.
  // Add  flutter_tts: ^4.0.0  to pubspec.yaml and restore _tts.speak() call.
  Future<void> _speakAlert(String message) async {
    _lastSpokenAlert = message;
    debugPrint('🔊 ALERT: $message');
    // Haptic as audio substitute until flutter_tts is added to pubspec
    HapticFeedback.heavyImpact();
  }

  // ── Public test methods ────────────────────────────────────────────────────
  Future<void> testVoiceAlert() async {
    await _speakAlert('Voice alert test — add flutter_tts to pubspec for audio.');
  }

  /// Plays the ambulance siren for 4 seconds then stops.
  /// Use the 🔊 button in MonitoringPage to test.
  Future<void> testAlarmSound() async {
    debugPrint('🧪 Testing ambulance siren...');
    await _playAmbulanceSiren();
    await Future.delayed(const Duration(seconds: 4));
    await _stopAlarm();
  }

  void resetBlinkCount() {
    _totalBlinkCount = 0;
    _blinkTimestamps.clear();
  }

  // ── Image conversion ───────────────────────────────────────────────────────
  InputImage? _convertCameraImageToInputImage(CameraImage image) {
    try {
      final rotation = _getRotationForDevice();
      final inputImageFormat = switch (image.format.group) {
        ImageFormatGroup.yuv420   => InputImageFormat.yuv420,
        ImageFormatGroup.bgra8888 => InputImageFormat.bgra8888,
        ImageFormatGroup.nv21     => InputImageFormat.nv21,
        _                         => InputImageFormat.nv21,
      };

      final WriteBuffer allBytes = WriteBuffer();
      for (final Plane plane in image.planes) {
        allBytes.putUint8List(plane.bytes);
      }
      final bytes = allBytes.done().buffer.asUint8List();

      final metadata = InputImageMetadata(
        size: Size(image.width.toDouble(), image.height.toDouble()),
        rotation: rotation,
        format: inputImageFormat,
        bytesPerRow: image.planes[0].bytesPerRow,
      );

      return InputImage.fromBytes(bytes: bytes, metadata: metadata);
    } catch (e) {
      debugPrint('Image conversion error: $e');
      return null;
    }
  }

  InputImageRotation _getRotationForDevice() {
    final orientation = _cameraDescription.sensorOrientation;
    if (_cameraDescription.lensDirection == CameraLensDirection.front) {
      switch (orientation) {
        case 90:  return InputImageRotation.rotation90deg;
        case 270: return InputImageRotation.rotation270deg;
        case 180: return InputImageRotation.rotation180deg;
        default:  return InputImageRotation.rotation0deg;
      }
    }
    return _rotationIntToInputImageRotation(orientation);
  }

  InputImageRotation _rotationIntToInputImageRotation(int rotation) {
    switch (rotation) {
      case 90:  return InputImageRotation.rotation90deg;
      case 180: return InputImageRotation.rotation180deg;
      case 270: return InputImageRotation.rotation270deg;
      default:  return InputImageRotation.rotation0deg;
    }
  }

  // ── Dispose ────────────────────────────────────────────────────────────────
  Future<void> dispose() async {
    try { await _cameraController.stopImageStream(); } catch (_) {}
    await _cameraController.dispose();
    await _eyeDetectionStream.close();
    await _blinkEventStream.close();
    await _faceDetector.close();
    try {
      await _stopAlarm();
    } catch (_) {}
  }
}